export interface QueryResult {
    success:string,
    _keyword_ : string,
    _transfer_id_ : string,
    data : Array<JSON>
}