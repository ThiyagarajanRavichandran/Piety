export interface TransactionResult {
    success:string,
    _keyword_ : string,
    _transfer_id_ : string
}