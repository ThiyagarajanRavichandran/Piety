import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-priest-list',
  templateUrl: './priest-list.component.html',
  styleUrls: ['./priest-list.component.css']
})
export class PriestListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
