import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-priest',
  templateUrl: './priest.component.html',
  styleUrls: ['./priest.component.css']
})
export class PriestComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
