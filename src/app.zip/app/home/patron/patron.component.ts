import { Component, OnInit, ViewChild  } from '@angular/core';

@Component({
  selector: 'app-patron',
  templateUrl: './patron.component.html',
  styleUrls: ['./patron.component.css']
})
export class PatronComponent implements OnInit {
 // @ViewChild('element') element;
  
  constructor() { }

  ngOnInit() { }
}