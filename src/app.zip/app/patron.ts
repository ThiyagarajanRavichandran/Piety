export interface IPatron {
    PatId : number,
    SSN : string,
    FirstName : string,
    MiddleName : string,
    LastName : string,
    DOB : string,
    CreatedBy : string
}